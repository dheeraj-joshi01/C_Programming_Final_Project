#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int count(char [], char []);

FILE *file, *stop;

int main()
{
	
	int cnt=0;
	char s[20], father[20], child[20], temp[20];
	
	scanf("%s", s);

	file = fopen("file.txt", "r");
	stop = file;
		
	while(!feof(stop))
	{
		fscanf(file, "%s %s\n", child, father);
							
		if(strcmp(father, s) == 0)
		{
			stop = file;
			rewind(file);
			
			do
			{
				fscanf(file, "%s %s", temp, father);
				cnt += count(child, father);
			} while(!feof(file));
			
		}

	}

	

	fclose(file);

	printf("%d\n", cnt);

	return 0;
}


int count(char child[20], char father[20])
{
	int c = 0;
	if(strcmp(child, father) == 0)
		{
			c++;
		}

	return c;
}


