#include<stdio.h>

int reverseBits(int);


int main()
{
	int num;
	
	printf("Enter the number : ");			//taking decimal number as inout
	scanf("%d", &num);
	
	reverseBits(num);	
	
	return 0;
}


int reverseBits(int n)						//function to convert decimal to binary
{
	int i = 0, len;
	int r[20];

	while(n != 0)
	{
		r[i] = n%2;
		n = n/2;
		i++;
	}

	len = i;
	
	printf("Before : ");
	
	for(i = len-1;i>=0;i--)
	{
		printf("%d", r[i]);
	}
	
	printf("\tAfter : ");
	
	for(i = 0;i<len;i++)
	{
		printf("%d", r[i]);
	}

	printf("\n");

	return 0;
}
