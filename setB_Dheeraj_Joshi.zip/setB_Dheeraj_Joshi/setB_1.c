#include<stdio.h>
#include<string.h>

int main()
{
	int i,j,k,n, count;
	char temp;
	printf("Enter length of string : ");
	scanf("%d", &n);

	char str[n+1], final[n+1];
	scanf("%s", str);
	
	k = -1;
	
	
	for(i=0;i<n;i++)
	{
		if(str[i] == temp)
		{
			continue;
		}

		count = 0;
		
		for(j=0;j<n;j++)
		{
			if(i == j)
			{
				continue;
			}
		
			if(str[i] == str[j])
			{
				count++;
			}
			continue;
		}

		if(count%2 == 0)
		{
			k++;
			final[k] = str[i];
		}

		temp = str[i];

	}

	if(k == -1)
	{
		printf("Empty String\n");
	}

	else
	{
		printf("%s\n", final);	
	}
	return 0;
}


